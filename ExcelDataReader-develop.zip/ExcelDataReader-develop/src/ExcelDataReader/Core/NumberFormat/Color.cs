﻿namespace ExcelDataReader.Core.NumberFormat
{
    internal sealed class Color
    {
        public string Value { get; set; }
    }
}
